/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import Modelo.Cliente;




public class Conector {
    
    private Connection conexion;
    

    public void Conector() {
        
        try
       {
           String url = "jdbc:mysql://localhost:3306/gymdb";
           String user = "root";
           String password = "";
           
           conexion = DriverManager.getConnection(url, user, password);
           System.out.println("Conexion Exitosa");
           
           
       } catch (SQLException e)
       {
           System.out.println(e.getMessage());
       }
        
    }
    
    public boolean agregarCliente (Cliente c)
    {
        try
        {
            String SQL = "INSERT INTO miembro (rut_duenio,nombre_duenio,marca,modelo,fecha,costo_mantencion) VALUES (?,?,?,?,?,?)";
            PreparedStatement pc = conexion.prepareStatement(SQL);
            
            pc.setString(1, c.getRut_duenio());
            System.out.println("Paso por punto a");
            pc.setString(2, c.getNombre_duenio());
                        System.out.println("Paso por punto b");

            pc.setString(3, c.getMarca());
                        System.out.println("Paso por punto c");

            pc.setString(4, c.getModelo());
                        System.out.println("Paso por punto d");

            pc.setString(5, c.getFecha());
                        System.out.println("Paso por punto e");

            pc.setInt(6, c.getCosto_mantencion());
                        System.out.println("Paso por punto f");

            
            pc.executeUpdate();
            pc.close();
                System.out.println("El cliente ha sido registrado con exito");
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());

            return false;
        }
        return true;
    }

    
    public boolean eliminarCliente (String rut)
    {
        try
        {
            String SQL = "DELETE FROM miembro WHERE rut_duenio = ?";
            PreparedStatement pc = conexion.prepareStatement(SQL);
            
            pc.setString(1, rut);
            pc.close();
               System.out.println("El cliente se eliminó");
            
        } catch (SQLException error_sql)
        {
            System.out.println("Error:" + error_sql.getMessage());
            return false;
        }
        return true;
    }

    public boolean actualizarCliente (Cliente c)
    {
        try
        {
            String SQL = "UPDATE miembro SET nombre_duenio = ? WHERE rut_duenio = ?";
            PreparedStatement pc = conexion.prepareStatement(SQL);
            
            
            pc.setString(2, c.getRut_duenio());
            pc.setString(1, c.getNombre_duenio());
           
            
            pc.executeUpdate();
            pc.close();

        } catch (SQLException error_sql)
        {
            System.out.println("Error:" + error_sql);
            return false;
        }
        return true;
    }
    
    public String buscarCliente()
    {
        String lista = "";
        
        try
        {
            String SQL = "Select * from miembro";
            PreparedStatement pc = conexion.prepareStatement(SQL);
            
            ResultSet rs = pc.executeQuery();
                while (rs.next())
                {
                    lista = lista + rs.getString("Rut: " + "-" + rs.getString("Nombre: " + "-" + rs.getString("Marca" + "-" + rs.getString("Modelo: " + "-" + rs.getString("Fecha de ingreso: " + "-" + rs.getInt("Costo de mantencion: "))))));
                }
         pc.close();
            System.out.println("....");
        } catch (SQLException error_sql){
            System.out.println("Error: "+ error_sql);
            return "";
        }
        return lista;
        
    }
    
    
}




