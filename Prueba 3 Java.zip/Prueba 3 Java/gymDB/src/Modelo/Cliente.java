/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.sql.Date;

/**
 *
 * @author ferna
 */
public class Cliente {
     private String rut_duenio;
    private String nombre_duenio;
    private String marca;
    private String modelo;
    private String fecha;
    private int costo_mantencion;

    public Cliente() {
    }

    public Cliente(String rut_duenio, String nombre_duenio, String marca, String modelo, String fecha, int costo_mantencion) {
        this.rut_duenio = rut_duenio;
        this.nombre_duenio = nombre_duenio;
        this.marca = marca;
        this.modelo = modelo;
        this.fecha = fecha;
        this.costo_mantencion = costo_mantencion;
    }

    public String getRut_duenio() {
        return rut_duenio;
    }

    public void setRut_duenio(String rut_duenio) {
        this.rut_duenio = rut_duenio;
    }

    public String getNombre_duenio() {
        return nombre_duenio;
    }

    public void setNombre_duenio(String nombre_duenio) {
        this.nombre_duenio = nombre_duenio;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getCosto_mantencion() {
        return costo_mantencion;
    }

    public void setCosto_mantencion(int costo_mantencion) {
        this.costo_mantencion = costo_mantencion;
    }

    @Override
    public String toString() {
        return "Cliente{" + "rut_duenio=" + rut_duenio + ", nombre_duenio=" + nombre_duenio + ", marca=" + marca + ", modelo=" + modelo + ", fecha=" + fecha + ", costo_mantencion=" + costo_mantencion + '}';
    }

    
    
    
}
